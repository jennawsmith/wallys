<?php
/*
Template Name: Contact
*/
get_header(); ?>



<?php get_footer(); ?>
