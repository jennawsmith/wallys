<?php
/*------------------------------------*\
	Custom Post Types
	Copy generated code from the Advanced Custom Fields Plugin
\*------------------------------------*/