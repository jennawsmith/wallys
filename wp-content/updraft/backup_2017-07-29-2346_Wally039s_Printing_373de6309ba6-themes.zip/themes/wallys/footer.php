		<?php wp_footer(); ?>


		<!-- TODO: ADD GOOGLE ANALYTICS -->

	</body>
	<footer class="footer">

			<div class="contact left">
					<h3>CONTACT:</h3>
					<p class="whitespace">
					Monday - Friday
					8:30 am - 5:30 pm
					Closed Saturday and Sunday
					</p>
					<p class="whitespace">
					969 N. Farnsworth Ave.
					Aurora, IL 60505
					630-851-3400
					sales@wallysprinting.com
					</p>
			</div>

			<div class="email_entry left">
					<h3>KEEP UP WITH US!</h3>
					<p>Enter Your Email Below:</p>
					<form id="email_box" action="">
							<input id="email" type="email">
							<input id="submit" type="submit" value=">">
					</form>
			</div>

			<div class="social_media left">
					<ul>
							<li><a href="facebook.com" target="_blank"><img src="<?php bloginfo('template_directory');?>/images/cfacebooklogo.svg" alt="facebook"/> </a></li>
							<li><a href="twitter.com" target="_blank"><img src="<?php bloginfo('template_directory');?>/images/ctwitterlogo.svg" alt="twitter"/></a></li>
							<li><a href="instagram.com" target="_blank"><img src="<?php bloginfo('template_directory');?>/images/cinstagram.svg" alt="instagram"/> </a></li>
							<li><a href="youtube.com" target="_blank"><img src="<?php bloginfo('template_directory');?>/images/cyoutube.svg" alt="youtube"/> </a></li>
					</ul>
			</div>

			<div class="copyright clear">
					Copyright &copy; 2017. <a href="http://wallysprinting.com" target="_blank">Wally's Printing.</a> All Rights Reserved.
			</div>
	</footer>
</div>

</body>
</html>
