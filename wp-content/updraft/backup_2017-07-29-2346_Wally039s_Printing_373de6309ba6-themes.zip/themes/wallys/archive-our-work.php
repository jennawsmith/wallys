<?php get_header(); ?>

    <!-- BODY CONTENT -->

<?php get_footer(); ?>
